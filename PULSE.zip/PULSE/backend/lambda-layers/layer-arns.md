# Lambda Layer ARNs Used

This file documents all Lambda layers used across the Pulse backend services.

---

## Bcrypt Layer

Used in:
- `login_user`
- `create_user`

ARN: `arn:aws:lambda:us-east-2:770693421928:layer:Klayers-p311-bcrypt:7`
