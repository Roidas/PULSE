// app.config.js
export default {
    projectRoot: "./frontend",
    expo: {
      name: "Pulse",
      slug: "pulse",
      version: "1.0.0",
      scheme: "pulse",
    },
    
  };
  