# process-friend-data Lambda

- Handles friend data from mobile app
- Saves GPS, SOS, distance from friends to DynamoDB
- Sends alerts via SNS based on SOS or distance checks
